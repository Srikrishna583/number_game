'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'

export default function GuessingGame() {
  const [secretNumber, setSecretNumber] = useState<number>(0)
  const [guess, setGuess] = useState<string>('')
  const [feedback, setFeedback] = useState<string>('')
  const [attempts, setAttempts] = useState<number>(0)
  const [gameOver, setGameOver] = useState<boolean>(false)
  const [won, setWon] = useState<boolean>(false)
  const [history, setHistory] = useState<number[]>([])
  const [bestScore, setBestScore] = useState<number | null>(null)

  useEffect(() => {
    initializeGame()
  }, [])

  const initializeGame = () => {
    const newNumber = Math.floor(Math.random() * 100) + 1
    setSecretNumber(newNumber)
    setGuess('')
    setFeedback('')
    setAttempts(0)
    setGameOver(false)
    setWon(false)
    setHistory([])
  }

  const handleGuess = () => {
    if (!guess || isNaN(parseInt(guess))) {
      setFeedback('Please enter a valid number!')
      return
    }

    const userGuess = parseInt(guess)

    if (userGuess < 1 || userGuess > 100) {
      setFeedback('Please enter a number between 1 and 100!')
      return
    }

    const newAttempts = attempts + 1
    setAttempts(newAttempts)
    setHistory([...history, userGuess])

    if (userGuess === secretNumber) {
      setWon(true)
      setGameOver(true)
      setFeedback(`🎉 You won! The number was ${secretNumber}!`)
      if (!bestScore || newAttempts < bestScore) {
        setBestScore(newAttempts)
      }
    } else if (userGuess < secretNumber) {
      setFeedback(`📈 Too low! Try a higher number.`)
    } else {
      setFeedback(`📉 Too high! Try a lower number.`)
    }

    setGuess('')
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleGuess()
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/20 via-background to-accent/20 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-2">
            Number Game
          </h1>
          <p className="text-muted-foreground text-lg">
            Guess the number between 1 and 100
          </p>
        </div>

        <Card className="p-8 shadow-lg bg-white dark:bg-slate-800 border-2 border-primary/20">
          {/* Game Card */}
          <div className="space-y-6">
            {/* Attempts Counter */}
            <div className="flex justify-between items-center">
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-1">Attempts</p>
                <p className="text-3xl font-bold text-primary">{attempts}</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-1">Best Score</p>
                <p className="text-3xl font-bold text-accent">
                  {bestScore ? bestScore : '—'}
                </p>
              </div>
            </div>

            {/* Feedback Message */}
            {feedback && (
              <div
                className={`p-4 rounded-lg text-center font-semibold text-base transition-all duration-300 ${
                  won
                    ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200'
                    : feedback.includes('Too')
                      ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200'
                      : 'bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-200'
                }`}
              >
                {feedback}
              </div>
            )}

            {/* Input Section */}
            {!gameOver ? (
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    type="number"
                    min="1"
                    max="100"
                    value={guess}
                    onChange={(e) => setGuess(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Enter your guess..."
                    className="text-lg py-6 border-2 border-primary/30 focus:border-primary"
                    disabled={gameOver}
                  />
                  <Button
                    onClick={handleGuess}
                    disabled={gameOver}
                    className="px-6 font-bold text-base bg-primary hover:bg-primary/90 text-primary-foreground"
                  >
                    Guess
                  </Button>
                </div>
              </div>
            ) : (
              <Button
                onClick={initializeGame}
                className="w-full py-6 text-lg font-bold bg-secondary hover:bg-secondary/90 text-secondary-foreground"
              >
                Play Again
              </Button>
            )}

            {/* Guess History */}
            {history.length > 0 && (
              <div>
                <p className="text-sm font-semibold text-muted-foreground mb-3">
                  Your guesses:
                </p>
                <div className="flex flex-wrap gap-2">
                  {history.map((num, idx) => (
                    <div
                      key={idx}
                      className={`px-3 py-1 rounded-full text-sm font-semibold transition-all ${
                        num === secretNumber
                          ? 'bg-green-500 text-white'
                          : num < secretNumber
                            ? 'bg-blue-500 text-white'
                            : 'bg-red-500 text-white'
                      }`}
                    >
                      {num}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Game Info */}
            <div className="bg-accent/10 dark:bg-accent/20 rounded-lg p-4 text-sm text-muted-foreground">
              <p className="font-semibold text-foreground mb-2">How to play:</p>
              <ul className="space-y-1 text-xs">
                <li>🎯 Make a guess between 1 and 100</li>
                <li>📊 Get hints if your guess is too high or too low</li>
                <li>⭐ Try to find the number in the fewest attempts</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}
